$(function () {

});

const changeDepartaments = (value) => {
    clearSelectMunicipalities();
    changeMunicipalities(value);
}
